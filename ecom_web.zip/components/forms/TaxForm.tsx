'use client';
import { useState } from 'react';
import { Loader, X } from 'lucide-react';

interface TaxSetting {
  id?: string;
  name: string;
  rate: number;
  type: 'percentage' | 'fixed';
  isDefault: boolean;
  regions: string[];
}

interface TaxFormProps {
  tax?: TaxSetting;
  onSave: (tax: TaxSetting) => Promise<void>;
  onCancel: () => void;
  isOpen: boolean;
}

export const TaxForm: React.FC<TaxFormProps> = ({ tax, onSave, onCancel, isOpen }) => {
  const [formData, setFormData] = useState({
    name: tax?.name || '',
    rate: tax?.rate || 0,
    type: tax?.type || 'percentage' as const,
    isDefault: tax?.isDefault || false,
    regions: tax?.regions || ['']
  });
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    
    const taxData = {
      id: tax?.id,
      ...formData
    };
    
    await onSave(taxData as TaxSetting);
    setSaving(false);
  };

  const addRegion = () => {
    setFormData(prev => ({
      ...prev,
      regions: [...prev.regions, '']
    }));
  };

  const removeRegion = (index: number) => {
    setFormData(prev => ({
      ...prev,
      regions: prev.regions.filter((_, i) => i !== index)
    }));
  };

  const updateRegion = (index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      regions: prev.regions.map((region, i) => i === index ? value : region)
    }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">
            {tax ? 'Edit Tax Setting' : 'Add Tax Setting'}
          </h3>
          <button
            onClick={onCancel}
            className="text-gray-400 hover:text-gray-600"
            disabled={saving}
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Tax Name</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              className="w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="e.g., VAT, Sales Tax"
              required
              disabled={saving}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Tax Rate</label>
            <input
              type="number"
              step="0.01"
              min="0"
              value={formData.rate}
              onChange={(e) => setFormData({...formData, rate: Number(e.target.value)})}
              className="w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
              disabled={saving}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Type</label>
            <select
              value={formData.type}
              onChange={(e) => setFormData({...formData, type: e.target.value as 'percentage' | 'fixed'})}
              className="w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              disabled={saving}
            >
              <option value="percentage">Percentage (%)</option>
              <option value="fixed">Fixed Amount ($)</option>
            </select>
          </div>
          
          <div>
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={formData.isDefault}
                onChange={(e) => setFormData({...formData, isDefault: e.target.checked})}
                className="mr-2 text-blue-600 focus:ring-blue-500"
                disabled={saving}
              />
              <span className="text-sm font-medium">Default Tax Setting</span>
            </label>
            <p className="text-xs text-gray-500 mt-1">
              Default tax will be applied when no specific region tax is found
            </p>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Regions</label>
            {formData.regions.map((region, index) => (
              <div key={index} className="flex items-center mb-2">
                <input
                  type="text"
                  value={region}
                  onChange={(e) => updateRegion(index, e.target.value)}
                  className="flex-1 border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., US, CA, EU"
                  disabled={saving}
                />
                {formData.regions.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeRegion(index)}
                    className="ml-2 text-red-600 hover:text-red-800"
                    disabled={saving}
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
            ))}
            <button
              type="button"
              onClick={addRegion}
              className="text-sm text-blue-600 hover:text-blue-800"
              disabled={saving}
            >
              + Add Region
            </button>
          </div>
          
          <div className="flex justify-end space-x-2 pt-4">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 text-gray-600 border rounded-md hover:bg-gray-50"
              disabled={saving}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
              disabled={saving}
            >
              {saving && <Loader className="mr-2 h-4 w-4 animate-spin" />}
              {saving ? 'Saving...' : 'Save'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};